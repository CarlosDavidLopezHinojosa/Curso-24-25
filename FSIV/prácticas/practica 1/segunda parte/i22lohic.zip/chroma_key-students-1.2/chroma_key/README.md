# Composición de imágenes usando color (chroma key).

Vea la descripción de la práctica [aqui](https://docs.google.com/document/d/13tJ5_ynfuh1VYu_Ua2vzmwLWrtpWyiC-xPznnlbxbs8/edit?usp=sharing)
